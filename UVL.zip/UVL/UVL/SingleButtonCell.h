//
//  SingleButtonCell.h
//  UVL
//
//  Created by Osama on 31/10/2016.
//  Copyright © 2016 TxLabz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
@interface SingleButtonCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *btn;
@end
