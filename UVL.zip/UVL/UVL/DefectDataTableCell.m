//
//  DefectDataTableCell.m
//  UVL
//
//  Created by cellzone on 1/27/21.
//  Copyright © 2021 TxLabz. All rights reserved.
//

#import "DefectDataTableCell.h"

@implementation DefectDataTableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
