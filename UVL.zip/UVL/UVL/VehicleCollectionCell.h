//
//  VehicleCollectionCell.h
//  UVL
//
//  Created by Osama on 02/11/2016.
//  Copyright © 2016 TxLabz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VehicleCollectionCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UILabel *makeModel;
@end
