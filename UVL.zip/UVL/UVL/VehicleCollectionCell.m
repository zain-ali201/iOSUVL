//
//  VehicleCollectionCell.m
//  UVL
//
//  Created by Osama on 02/11/2016.
//  Copyright © 2016 TxLabz. All rights reserved.
//

#import "VehicleCollectionCell.h"

@implementation VehicleCollectionCell

@end
