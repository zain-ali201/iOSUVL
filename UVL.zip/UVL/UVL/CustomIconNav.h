//
//  CustomIconNav.h
//  UVL
//
//  Created by Osama on 17/11/2016.
//  Copyright © 2016 TxLabz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomIconNav : UINavigationItem

@end
