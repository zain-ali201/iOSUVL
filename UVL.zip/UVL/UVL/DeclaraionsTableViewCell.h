//
//  DeclaraionsTableViewCell.h
//  UVL
//
//  Created by Osama on 31/10/2016.
//  Copyright © 2016 TxLabz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeclaraionsTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *checkBox;
@property (strong, nonatomic) IBOutlet UILabel *desc;
@end
