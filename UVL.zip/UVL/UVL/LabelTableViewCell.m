//
//  LabelTableViewCell.m
//  UVL
//
//  Created by Ahmed Sadiq on 21/08/2017.
//  Copyright © 2017 TxLabz. All rights reserved.
//

#import "LabelTableViewCell.h"

@implementation LabelTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
