//
//  UVLTabVC.h
//  UVL
//
//  Created by Osama on 06/05/2017.
//  Copyright © 2017 TxLabz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UVLTabVC : UITabBarController

@end
