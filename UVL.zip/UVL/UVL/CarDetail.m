//
//  CarDetail.m
//  UVL
//
//  Created by Zaryab Hassan on 06/12/2018.
//  Copyright © 2018 TxLabz. All rights reserved.
//

#import "CarDetail.h"

@implementation CarDetail

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
