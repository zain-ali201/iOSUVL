//
//  Header.h
//  UVL
//
//  Created by Zaryab Hassan on 06/12/2018.
//  Copyright © 2018 TxLabz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarDetail : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;

@end
