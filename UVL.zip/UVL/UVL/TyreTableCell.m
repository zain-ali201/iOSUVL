//
//  TyreTableCell.m
//  UVL
//
//  Created by cellzone on 2/9/21.
//  Copyright © 2021 TxLabz. All rights reserved.
//

#import "TyreTableCell.h"

@implementation TyreTableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
